Author: Allison Kaptur
Project: Byterun
Requirements: Python

Byterun

Byterun is a pure-Python implementation of a Python bytecode interpreter.  This incarnation is a fork from @nedbat's [byterun](https://github.com/nedbat/byterun/).