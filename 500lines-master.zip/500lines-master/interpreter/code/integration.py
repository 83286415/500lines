# A file to test if pyvm works from the command line.

def it_works():
    print("Success!")

it_works()
