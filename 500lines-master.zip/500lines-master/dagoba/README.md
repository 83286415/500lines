# Dagoba

An extensible in-memory graph database

Author: Dann Toliver

See the main repo for the living version: https://github.com/dxnn/dagoba

Some tests here: http://bentodojo.com/dagoba/tests/
