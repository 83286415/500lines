Author: Dustin J. Mitchell
Project: Cluster (a working title!)
Requirements: Python

This directory holds a simple implementation of a replicated state machine
using a Paxos-derived algorithm.

Goals:

Every programmer should know how consensus is achieved across a network of hosts.
And every programmer ought to know how network protocols are implemented, tested, and debugged.
