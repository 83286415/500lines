Author: Cate Huston
Project: Image Filter App
Requirements:
- Java 1.6 or above
- core.jar from Processing 2.1.1
- mockito 1.9.5

Run ImageFilterApp as a Java application.