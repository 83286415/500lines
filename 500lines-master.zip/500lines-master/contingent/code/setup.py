from distutils.core import setup
setup(
    name='contingent',
    version='0.1',
    packages=['contingent'],
    )
