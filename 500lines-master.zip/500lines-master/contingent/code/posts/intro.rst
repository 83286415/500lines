
==============
 Introduction
==============

:Date: 2014/02/28

Several readers have been asking
for a series of articles about mathematics,
so the next several blog posts will be about
fundamental mathematical operations.
