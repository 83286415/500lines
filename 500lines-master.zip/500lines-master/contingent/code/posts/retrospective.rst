
=================
 A Retrospective
=================

:Date: 2014/03/20

Having looked at title_of(addition.ipynb)
and title_of(subtraction.ipynb)
in our previous two blog posts, we can conclude
that addition is safe but that subtraction is scary.
