Author: Ned Batchelder
Project: Template engine
Requirements: Python

This directory contains a simple templating engine, such as you might use to
generate HTML in a web application.

To run the tests::

    $ python -m unittest discover
