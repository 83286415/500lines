*   Use BaseHTTPServer to handle socket connections and parse HTTP requests.
*   Respond to GET requests with a static 'page'.
*   To test:
    *   Run `python server.py`.
    *   Point browser at `http://localhost:8080/`
