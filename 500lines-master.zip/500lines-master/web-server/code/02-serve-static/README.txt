This version responds to HTTP requests with static HTML files or
directory listings.

*   Run with `python server.py .` (or some other base directory name).
*   Point browser at `http://localhost:8080/some/path`.
