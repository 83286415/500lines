*   Respond to GET requests with information about the request.
*   To test:
    *   Run `python server.py`.
    *   Point browser at `http://localhost:8080/something/or/other`
