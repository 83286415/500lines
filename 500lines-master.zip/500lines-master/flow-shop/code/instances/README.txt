Instances can be found at http://mistic.heig-vd.ch/taillard/problemes.dir/ordonnancement.dir/ordonnancement.html

For this work, we completely disregard the first 3 lines of every instance
 and use only the operation times as input. The format is not ideal for python
 input, but it is a standard in the research community.
