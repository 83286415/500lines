"""
Silly example code to try the compiler on.
"""

#import math
print(['m', 'n'][0])
(pow, len)
{'a': 42, 'b': 55}
{}
None
ga = 2+3
def f(a):
    "doc comment"
    while a and True:
        pass
        if False or a != 1 or False:
            print(a, 137)
        a = a - 1
    return pow(2, 16)
    return
print(f(ga))
t = True
while t:
    break
for j, i in enumerate(range(3)):
    print(i)
#print(-math.sqrt(2))
raise Exception('hi')
