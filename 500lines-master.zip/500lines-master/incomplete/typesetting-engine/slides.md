# The Frog King

In olden times when wish·ing still helped one, there lived a king whose daugh·ters were all beau·ti·ful; and the young·est was so beau·ti·ful that the sun it·self, which has seen so much, was aston·ished when·ever it shone in her face. Close by the king's castle lay a great dark for·est, and un·der an old lime-tree in the for·est was a well, and when the day was very warm, the king's child went out into the for·est and sat down by the side of the cool foun·tain; and when she was bored she took a golden ball, and threw it up on high and caught it; and this ball was her favor·ite play·thing.

# Girls Can Code!

- Du joli code
- Des boissons
- Du fun

# Mary Poppins

I assume you like Disney movies. Have you ever heard of the word super·cali·fragi·listic·expi·alidocious? Because it's a pain to hyphenate. Anyway, here is an example. The word was hyphenated in order not to stretch the spaces too much.

# Adjustment

a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a a 
