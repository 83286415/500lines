A_Song_of_Ice_and_Fire.jpg is © 2013 Romain Guy.

License:
CreativeCommons Attribution-NonCommercial-NoDerivs 3.0 Unported (CC BY-NC-ND 3.0)
http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US

For more information please visit:

Personal blog (photos)
http://www.curious-creature.org

Google+ profile
https://plus.google.com/109538161516040592207

Flickr profile
http://flickr.com/photos/romainguy
