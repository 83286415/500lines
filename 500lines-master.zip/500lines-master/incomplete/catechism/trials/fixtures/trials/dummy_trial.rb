require 'catechism'

describe 'life' do
  it 'is a bummer' do
    expect('stuff').not.to_equal('great')
  end
end