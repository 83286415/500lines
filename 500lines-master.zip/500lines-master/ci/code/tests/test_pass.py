import unittest

class TestFilePass(unittest.TestCase):

    def test_pass(self):
        self.assertTrue(True)
